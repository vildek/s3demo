console.info(
  `%c s3Demo %c Author: Kaspars Vilde`,
  "background: #449d44; color: #fff; font-size: 0.75rem; border-radius: 0.25rem 0 0 0.25rem; font-family: Tahoma; padding: 0.25rem;",
  "background: #b2cc97; color: #3f6063; font-size: 0.75rem; border-radius: 0 0.25rem 0.25rem 0; font-family: Tahoma; padding: 0.25rem;"
);